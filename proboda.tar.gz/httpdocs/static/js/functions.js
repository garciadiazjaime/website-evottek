// Author: Mint IT Media
$(document).ready(function(){
	//load_scroll_menu();
	//load_contact_form();
	//scrollster();
	
	//$('body').scrollspy({ target: '#main_menu_container', offset: 600 });
	$('body').animate({
		'background': '#f2f2f2 url(#{$img}bkg_pattern.jpg) repeat',
		'opacity': '1'
	})
	// PROBODA FUNCTIONS
	set_main_banner();
	$("#carousel_services").carousel({interval: 0})
	$("#carousel_coordinacion").carousel({interval: 0});
	$("#carousel_fiestas").carousel({interval: 0});
	$("#carousel_servicios").carousel({interval: 0});
	move_carousel();
	about_us();
	about_us_en();
	contact_us();
	rosas_chocolate_on();
	rosas_chocolate_off();
	services_hover();
	pushy_menu();
	$('#contact_form_submit').click(function(){
		errors = []
		if (validate_section('#contact_form')){
			$('#form-msg').html('');
			$('#form-msg').addClass('loading-ajax');
			send_message(get_message_data(), '#contact_form', '#form-msg');
		} else {
			$('#form-msg').removeClass('text-success').addClass('text-danger form-msg-block').html(get_error_list());
		}
		return false;
	});
});

/*
	function validate contact form

function load_contact_form(){
	var fields = new Array('name', 'last_name', 'email', 'message');
	var is_ready = true;
	$('#contact_msg').removeClass();
	$('#contact_form').submit(function(){
		is_ready = true;
		for(var i=0; i<fields.length; i++){
			if($('#'+fields[i]).val() == ''){
				$('#'+fields[i]).addClass('required');
				is_ready = false;
			}else{
				$('#'+fields[i]).removeClass('required');
			}
		}

		if(is_ready){
			$('#contact_msg').addClass('bg-warning').text('Sending, please wait. ').append(loading);
			$.post( "send_msg",{ 
				'name': $('#name').val(),
				'last_name': $('#name').val(),
				'email': $('#email').val(),
				'message': $('#message').val()
				}).done(function( data ) {
					if(data == "true"){
						$('#contact_msg').removeClass().addClass("bg-success").text("Thanks, we'll contact you asap.");
						clearForm('contact_form');
					}else{
						$('#contact_msg').addClass('bg-danger').text('Error, please try later.');			
					}
				});
		}else{
			$('#contact_msg').addClass('bg-danger').text('Error, please fill all the fields');
		}
		return false;
	});
}*/

/*
	function to clear all input fields inside an element
*/
function clearForm(id)
{
    $('#'+id+'>input, #'+id+'>textarea').not(':button, :submit, :reset, :hidden').val('');
}

// ********* PROBODA FUNCTIONS **************

/*
	function to set the margins of centered elements.
*/
function set_main_banner(){	
	if($(window).width()>=767){
		$('#main_content').css('margin-top', $("#header").height()+30);
		$('#main_content').css('height', $(window).height()-$("#header").height()-30-98);
	}
	else{
		$('#main_content').css('margin-top', $("#header").height());
		$('#main_content').css('height', $(window).height()-$("#header").height());
	}
	
	$('.carousel .carousel .item').css('height', $('#main_content').height()-80);
	$('.carousel-control').css('margin-top', $('#main_content').height()/2-15);
}

/*
	functions to enable carousel button navigation, have services shrink after clicking on one, and adding the active class to the first item of each carousel (this is to allow nested carousels)
*/
function move_carousel(){
	$('.carousel-navigator').click(function (e){
		var position = parseInt(this.getAttribute('data-to'));
		$('#carousel_services').carousel(position);
		carousel_positions();
		$( "#services" ).css('height', 98);
	});
}
function carousel_positions(){
	$('#carousel_coordinacion .carousel-inner div:first-child').addClass('active');
	$('#carousel_fiestas .carousel-inner div:first-child').addClass('active');
	$('#carousel_servicios .carousel-inner div:first-child').addClass('active');

	$('#carousel_rosas_bodas .carousel-inner div:first-child').addClass('active');
	$('#carousel_rosas_xv .carousel-inner div:first-child').addClass('active');
	$('#carousel_rosas_despedidas .carousel-inner div:first-child').addClass('active');
	$('#carousel_rosas_popurri .carousel-inner div:first-child').addClass('active');
}

/*
	Function to enable the hover of #services without inerfering with move_carousel()
*/
function services_hover(){
	$('#services').mouseover(function (e){
		$( "#services" ).css('height', 430);
	});
	$('#services').mouseleave(function (e){
		$( "#services" ).css('height', 98);
	});
}
/*
	function to display the about us fancybox
*/
function about_us(){
	$('.nosotros, #about_us_fb .closer, #about_us_fb .fancy_background').click(function (e){
		about_us = document.getElementById( 'about_us_fb' );
		classie.toggle( about_us, 'display_blocker' );
		classie.toggle( about_us, 'display_noner' );
		if($(window).width()>=767){
			$('#about_us_fb .fancy_container').css('top', ($(window).height()-$('#about_us_fb .fancy_container').height())/2);
			$('#about_us_fb .fancy_container').css('left', ($(window).width()-$('#about_us_fb .fancy_container').width())/2);
		}
	});
}
/*
	function to display the about us english fancybox
*/
function about_us_en(){
	$('.nosotros_en, #about_us_fb_en .closer, #about_us_fb_en .fancy_background').click(function (e){
		about_us_en = document.getElementById( 'about_us_fb_en' );
		classie.toggle( about_us_en, 'display_blocker' );
		classie.toggle( about_us_en, 'display_noner' );
		if($(window).width()>=767){
			$('#about_us_fb_en .fancy_container').css('top', ($(window).height()-$('#about_us_fb_en .fancy_container').height())/2);
			$('#about_us_fb_en .fancy_container').css('left', ($(window).width()-$('#about_us_fb_en .fancy_container').width())/2);
		}
	});
}
/*
	function to display the contact us fancybox
*/
function contact_us(){
	$('.contacto, #contact_us_fb .closer, #contact_us_fb .fancy_background').click(function (e){
		contact_us = document.getElementById( 'contact_us_fb' );
		classie.toggle( contact_us, 'display_blocker' );
		classie.toggle( contact_us, 'display_noner' );
		$('#contact_us_fb .fancy_container').css('top', ($(window).height()-$('#contact_us_fb .fancy_container').height())/2);
		$('#contact_us_fb .fancy_container').css('left', ($(window).width()-$('#contact_us_fb .fancy_container').width())/2);
	});
}
/*
	functions to make everything pink while on rosas chocolate.
*/
function rosas_chocolate_on(){
	$('.rosaschocolate, .rosas').click(function (e){
		if($( "#logo" ).hasClass( "green" )){
			logo = document.getElementById('logo');
			classie.toggle(logo, 'green');
			classie.toggle(logo, 'pink');

			main_menu = document.getElementById('main_menu');
			classie.toggle(main_menu, 'green');
			classie.toggle(main_menu, 'pink');

			header = document.getElementById('header');
			classie.toggle(header, 'green');
			classie.toggle(header, 'pink');

			social = document.getElementById('social_media_icons');
			classie.toggle(social, 'green');
			classie.toggle(social, 'pink');

			maincontent = document.getElementById('main_content');
			classie.toggle(maincontent, 'green');
			classie.toggle(maincontent, 'pink');

			services = document.getElementById('services');
			classie.toggle(services, 'display_toggler');
			classie.toggle(services, 'display_noner');

			menurosas = document.getElementById('menu_rosas');
			classie.toggle(menurosas, 'display_toggler');
			classie.toggle(menurosas, 'display_noner');
		}
	});
}
/*
	functions to make everything green when leaving rosas chocolate
*/
function rosas_chocolate_off(){
	$('.inicio, .nosotros, .contacto, .proboda, nosotros_en').click(function (e){
		if($( "#logo" ).hasClass( "pink" )){
			logo = document.getElementById('logo');
			classie.toggle(logo, 'green');
			classie.toggle(logo, 'pink');

			main_menu = document.getElementById('main_menu');
			classie.toggle(main_menu, 'green');
			classie.toggle(main_menu, 'pink');

			header = document.getElementById('header');
			classie.toggle(header, 'green');
			classie.toggle(header, 'pink');

			social = document.getElementById('social_media_icons');
			classie.toggle(social, 'green');
			classie.toggle(social, 'pink');

			maincontent = document.getElementById('main_content');
			classie.toggle(maincontent, 'green');
			classie.toggle(maincontent, 'pink');

			services = document.getElementById('services');
			classie.toggle(services, 'display_toggler');
			classie.toggle(services, 'display_noner');

			menurosas = document.getElementById('menu_rosas');
			classie.toggle(menurosas, 'display_toggler');
			classie.toggle(menurosas, 'display_noner');
		
		}
	});
}

// *************************** Push menu, from left ***********************

function pushy_menu(){
	var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
	showLeftPush = document.getElementById( 'showLeftPush' ),
	header = document.getElementById( 'header' ),
	body = document.body;

	showLeftPush.onclick = function(e) {
		e.preventDefault();
		classie.toggle( this, 'active' );
		classie.toggle( body, 'cbp-spmenu-push-toright' );
		classie.toggle( header, 'cbp-spmenu-push-toright' );
		classie.toggle( menuLeft, 'cbp-spmenu-open' );
		//disableOther( 'showLeftPush' );
	};
	$('.cbp-spmenu').click(function (e){
		e.preventDefault();
		classie.toggle( this, 'active' );
		classie.toggle( body, 'cbp-spmenu-push-toright' );
		classie.toggle( header, 'cbp-spmenu-push-toright' );
		classie.toggle( menuLeft, 'cbp-spmenu-open' );
	});
	$('.social_mobile a').click(function (e){
        URL = $(this).attr("href");
        window.open(URL,'_blank');
	});
	$('.english_link').click(function (e){
		console.log("sfgasfgsgf");
        URL = $(this).attr("href");
        window.open(URL,'_self');
	});
}
