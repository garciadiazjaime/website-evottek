<div class="row">
	<div class="col-xs-5">
		
	</div>
	<div class="col-xs-7">
		<div class="wrap">
			<span class="logo"></span>
			<h3><span>Traveler - <em>??????</em></span></h3>
			<p><strong>The Traveler</strong> is high performance board 8" longer, round pin tail and an agresive rocket. Great for getting into tubular waves without the feeling that you're riding a shortboard. </p>
			
			<h3><span>Wave height - <em>Overhead high</em></span></h3>
			<img src="/static/img/surfboard/traveler_wave_height.jpg" alt="Wave height">

			<h3><span>Skill level - <em>Intermediate/Pro</em></span></h3>
			<img src="/static/img/surfboard/traveler_skill_level.jpg" alt="Skill level">
			
		</div>
	</div>
</div>

<p>test</p>