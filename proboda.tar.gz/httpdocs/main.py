from flask import Flask, render_template, request, jsonify
from flask_mail import Mail, Message

import json
#from flask.ext.mail import Mail, Message

app = Flask(__name__)
mail = Mail(app)
#mail = Mail(app)

@app.route("/")
def home():
	return render_template('index.html', name='index')
@app.route("/english")
def english():
	return render_template('english.html', name='index')

@app.route("/send_msg", methods=['POST','GET'])
def send_msg():
	response = { 'status' : False }

	if request.method == 'POST':
		try:
			nombre = request.form['nombre']
			correo = request.form['correo']
			telefono = request.form['telefono']
			mensaje = request.form['mensaje']

			body = 'Nombre: ' + nombre
			body += '\nCorreo Electronico: ' + correo
			body +='\nTelefono: ' + telefono
			body +='\nMensage: ' + mensaje

			msg = Message("Contacto Web Proboda",
			  					sender=correo,
			  					recipients=["info@proboda.com.mx"])
			msg.body = body
			mail.send(msg)
			response = { 'status' : True}

		except Exception, e:
			print e
		
		return jsonify(response)
	return False


if __name__ == "__main__":
	app.debug = True
	app.run('')